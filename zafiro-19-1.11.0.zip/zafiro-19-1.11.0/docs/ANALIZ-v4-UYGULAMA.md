# Analiz v4 → uygulama eşlemesi (v1.21.0-superagent)

`Zafiro-Analiz-v4-Super-Agent.md` bulgularına karşı yapılan kod değişiklikleri ve
dürüst kalan sınırlar. Öncelik sırası: P0 ölçüm doğruluğu → P1 sınav geometrisi →
P2 arena → P3/P4 kalıtım ve prompt.

## R1 — Sınav kâğıdı ≠ sınav salonu ⛔ → katmanlı sınav

- `EvalCase.tier: SANDBOX | SUPERVISED` eklendi. `SANDBOX` vakaların `toolsExpected`
  kümesi `EvalSafety.SAFE_TOOLS` içinde olmak **zorunda**; değilse `EvalAudit` hata yazar.
- `evals_run(live=true)`:
  - varsayılan olarak **araçsız** sandbox vakalarını seçer (10 vaka),
  - `SUPERVISED` vakaları **koşmaz**, gerekçeli `blocked` kaydı yazar (başarı sayılmaz),
  - `live_tools` sessizce düşürülmez: güvenli olanlar `tools`, güvenli olmayanlar
    `rejected_tools` alanında döner.
- `EvalResult` artık `tier` ve `blocked` taşır; `evals_list` `sandbox/supervised`
  sayılarını ve tier denetimini gösterir.
- **Kalan sınır:** `SUPERVISED` katmanı (geçici kök + dry_run + otomatik geri alma)
  henüz uygulanmadı; bu yüzden SUPERVISED vakalar ölçüme girmiyor, açıkça "blocked".

## R2 — Fitness'ın 5 metriği sabit → `Double?`

- `FitnessMetrics` alanları `Double?`. `null` = ölçülmedi; JSON `null`, pano `—`.
  `metrics_version=2`; eski `0.0/1.0` varsayımları okunurken atılır.
- `defense = null` (canlı arena yoksa), `overRefusal/refusalQuality` vicdan
  jurnali + etiket yoksa `null`, `selfFixHours/regressionRate/survival` `null`.
- Her metriğin `samples`'ı var; `Fitness.compare` iki tarafta da **n≥10** değilse
  `verdict="insufficient"` ("değerlendirilemedi"). Kritik metrikler: başarı, savunma,
  aşırı ret. Hiçbir metrik varsayılan olarak iyi değil.
- **Kalan sınır:** aşırı ret/ret kalitesi yalnızca `conscience_label` ile etiketlenen
  kayıtlardan ölçülür; etiket yoksa `null`.

## R3 — Ölçümler kuşağa bağlı değil → generation zorunlu

- `arena_run`, `arena_judge`, `evals_run` boş `generation_id` gelirse **aktif kuşağı**
  enjekte eder; kayıtlarda `generation_id` dolu.
- `status` ve `dashboard` yalnızca aktif kuşağın ölçümlerini gösterir.
- `genome branch` ve `genome sync` artık **genom + aday kuşak** doğurur; soy ağacında
  kuşağı olmayan genom kalmaz. `active_genome.json` işaretçisi eklendi.

## R4 — İki farklı gerçek → tek kaynak + kaynak etiketi

- `evolution_status` artık `evals.total=50`, `visible=30`, `held_out=20` diyor
  (önce 30/0 idi). `arena` canlı/statik sayılarını ayrı veriyor.
- `source: {file:"state.json", mtime_ms, generation_id, stage_in_state}` eklendi;
  `lineage` aynı `status` nesnesini taşıyor.
- **Kalan:** jurnal ile telemetri hâlâ iki ayrı depo (R11); birleştirme yapılmadı.

## R5 — Disk ölçümü bozuk → gerçek kök

- `EnvironmentAdapter.fromDevice(storageRoot)` eklendi; `resource_report` app
  `files/evolution` kökünü geçiriyor. Disk 0 ise "ölçülemedi" denir; "disk az"
  varsayımı yapılmaz.

## R6 — `trace.jsonl` kopyaydı → ayrı, redakte iz

- `tools.jsonl`: yalnız metrik (araç, ok, kod, süre, turn_id, gen_id, args_hash,
  result_digest/bytes). Argüman/içerik yok.
- `trace.jsonl`: `args_digest`, `args_redacted` (≤800), `result_digest`, `result_bytes`,
  `turn_id`, `gen_id`, `flags`, `blob:null`. **Kopya değil.**
- Eski kopya izler açılışta temizlenir; 7 gün yaşlanır.
- `Redactor`: token/API key, Authorization, e-posta, telefon, IBAN, TCKN, JWT, PEM.
- **Kalan:** sonuç blob'u saklanmıyor (gizlilik); yeniden oynatma digest + redakte
  argümanla sınırlı.

## R7 — Arena kanıtsız → model-döngüde varsayılan

- `arena_run` artık **varsayılan `live=true`** (limit 5): payload gerçek sandbox
  ajanına gider; savunma yalnız tespit/ret kanıtıyla sayılır.
- `ArenaResult.mode = live|static`; fitness/status **yalnız live** sonuçları kullanır.
  Eski (1.20) etiketsiz kayıtlar `static` sayılır, savunma skoruna girmez.
- `arena_run(live=false)` hâlâ var; "statik guard testi" olarak etiketlenir.

## R8 — Otonomi yok ⛔ → **kısmi: gece nöbeti**

- `NightShiftWorker` + `NightShiftScheduler` (WorkManager, günde 1, 02–04 arası):
  şarj + pil ≥ %60 + ekran kapalı koşulları sağlanmazsa **atlar ve kaydeder**;
  sağlanırsa `diagnose → statik arena → meta → kaynak raporu` koşar, sabah tek bildirim bırakır.
- Zaman aşımı (`night_max_minutes`) → güvenli mod; hata → not + başarısız iş.
- **Kalan:** `mission.json` / checkpoint / resume ve “gece başına 1 yama” yok;
  gece oturumu kod değiştirmez. Varsayılan `nightly_enabled=false`; `evolution_settings`
  ile açılır ve uygulama bir kez yeniden başlatılınca zamanlanır.

## R9 — L0 prompt Kotlin string'i → sürümlü prompt pack

- `PromptPackStore`: `base` paketi ilk açılışta seed edilir (hash'li).
- `genome action=prompt_save` paketi kaydeder, **genoma ekler** ve aday kuşak doğurur;
  `PromptComposer` aktif genomun paketlerini sistem promptuna ekler.
- `prompt_packs` girdisi `id@version` biçiminde; eski `base@1` etiketi artık gerçek
  `base` paketine çözülür.
- **Kalan:** paket başına eval deltası otomatik ölçülmüyor; `evals_run` ile manuel.

## R10 — İnsan onayı/aşırı ret ölçülmüyor → etiket + null

- `ConscienceLedger.metrics` gerçek etiketlerden `refusal_precision`, `over_refusal`,
  `refusal_recall` üretir; etiket yoksa `refusal_quality` `null`.
- Yeni `conscience_label` aracı: istek + zararlı mı bilgisini kaydeder; böylece
  fitness'taki `over_refusal/refusal_quality` ölçülebilir hâle gelir.
- Onay (approval) ölçümü hâlâ yok; onay/ret olayları jurnale yazılmıyor.

## R11 — Jurnal ≠ telemetri → **yapılmadı**

Telemetri hattı ayrı; jurnal ile birleştirme bu sürümde yok. Doc olarak açık.

## P0–P8 durumu

| Öncelik | Durum |
|---|---|
| P0 ölçüm (null, SoT, generation, trace) | ✅ |
| P1 sınav (tier, mühür, audit, canlı) | ⚠️ sandbox ✅, supervised blocked |
| P2 arena (live, judge, mode) | ✅ |
| P3 kalıtım (genome+generation) | ✅ |
| P4 prompt pack (L0) | ✅ |
| P5 otonomi | ⚠️ gece nöbeti var; mission/checkpoint yok |
| P6 alt ajan | ⚠️ `spawn_agent` (sandbox, özet) var; kalıcı roller yok |
| P7 bellek grafiği | ⛔ |
| P8 L4/L5 fabrika | ⛔ |

## Doğrulama

- `./gradlew :evolution:selfCheck` → **82 kontrol**, 0 hata (yerelde `kotlinc` + `java`).
- Arena statik korpus 40 senaryo, savunma yalnız kanıtlı; canlı mod ayrı.
- Katalog: 30 görünür + 20 mühürlü; tier denetimi boş, mutasyon denetimi boş.
- Trace redaksiyon testi: token/e-posta/telefon maskelenir; `tools.jsonl` içerik taşımaz.
- Sürüm: **1.21.0-superagent / versionCode 29**.

## Sonraki sürüm için en değerli üç iş

1. `SUPERVISED` eval katmanı: geçici kök + dry_run + tur sonu geri alma.
2. Mission/checkpoint + resume ve gece başına 1 yama kuralı.
3. Onay olaylarının ve aşırı ret etiketlerinin gerçek turlardan toplanması.
